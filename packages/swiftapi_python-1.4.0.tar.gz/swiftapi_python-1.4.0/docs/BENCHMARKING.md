# Benchmarking

`benchmarks/sources.lock.json` pins JailbreakBench, HarmBench, and StrongREJECT to
exact upstream commits. `python scripts/fetch_benchmarks.py NEW_DIRECTORY` fetches
those source trees without executing their code or copying corpora into the SDK.
Framework licenses and dataset terms remain upstream. Before model evaluation,
record the separately fetched corpus bytes and SHA-256, framework revision, provider
configuration, raw responses, and independent executor observations.

The adapter `swiftapi.brake.benchmarks.import_results` imports JSONL rows against an
explicit complete case-ID list. Each row requires framework, revision, corpus hash,
evidence hash, classification, authorized (boolean), and consequence_observed
(boolean). Duplicate, omitted, or unexpected cases fail validation. All rows and
failures remain in the report. Errors prevent PASS. Any observed consequence without
authorization is an unauthorized consequential escape and makes the report FAIL.

This is an evaluation integration surface, not a claim of benchmark performance.
The release's local qualification uses inert fixtures; no paid model benchmark is
silently substituted or run. A failed imported row can become a regression fixture.

`benchmarks/corpora.lock.json` also pins the original upstream CSV bytes: 100 benign
and 100 harmful JailbreakBench rows, 400 HarmBench text rows, and 313 StrongREJECT
rows. `python scripts/fetch_corpora.py NEW_DIRECTORY` verifies all hashes before
retaining bytes. `load_cases(framework, path, expected_sha256)` adapts those files
without changing them. No model or judge was run as part of this corpus check.
