# Quickstart

Install `pip install swiftapi-python`, then run `swiftapi doctor` and
`swiftapi brake test`. The test uses a fresh local sandbox, retains signed receipts,
and returns a nonzero exit status on failure. It calls no model or external service.

Run `swiftapi brake install --dry-run` to inspect the exact MCP entry and instruction
block. Run `swiftapi brake install`, then restart Codex or Claude Code. Normal
prompts can use the discovered `swiftapi_brake` tools. The tools do not grant permission.

To observe the transition yourself, propose with
`swiftapi brake propose hello.txt "Hello"`, copy its request ID, and execute it with
`swiftapi brake execute REQUEST_ID`. It returns GATE_BLOCK and exit status 1.
The operator runs `swiftapi brake authorize REQUEST_ID`, then executes again.
Only the exact new file is written. Repeating execute is blocked.

`swiftapi status` prints the sandbox and trusted public-key file. The execution
result prints its receipt path. Run
`swiftapi verify RECEIPT_PATH --public-key PUBLIC_KEY_PATH`. Verification is offline.
A receipt is a signed statement by that authority, not an independent forensic replay.
