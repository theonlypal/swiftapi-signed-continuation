# Conditions

BindingCondition binds one action hash and a nonempty required-state JSON object.
The implemented predicate is exact, type-sensitive canonical equality. For example,
boolean true differs from integer 1. Extra, absent, or changed state fields deny.
The condition name is also hashed; changing it invalidates previous authorization.

The caller supplies trusted current state and the expected prerequisite. The local
broker independently constructs state from its sandbox identity and target absence.
Operator authorization is an explicit, separate method, never an MCP tool. This
library is not a natural-language permission oracle and makes no extra LLM calls.

The object takes a detached snapshot when created. Use `to_dict()` to inspect the
canonical snapshot; modifying a supplied dictionary cannot change signed bytes.
A valid condition does not obligate execution; it permits a specific decision.
