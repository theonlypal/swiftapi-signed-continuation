# Concepts

A binding condition is the prerequisite that must hold for valid continuation.
Capability is what can be done; permission determines whether the particular
consequence may occur. The software contract is prerequisite → verify → authorize
→ consequence. A condition that cannot be verified permits no mediated consequence.

`ActionEnvelope` freezes the exact capability, parameters, intent, and actor.
`BindingCondition` binds its action hash and required state. `LocalAuthority`
evaluates equality and signs a short-lived `Decision`. `LocalGuard` or a broker
independently checks the signature and every binding before claiming the nonce.
`DecisionReceipt` is the signed-envelope type; execution receipts use a separate
schema to distinguish authorization from the subsequent effect.

State and conditions originate in trusted application code. An agent writing
"approved" in its prompt does not establish a real prerequisite. Model-native
termination is an independent behavioral observation, never the authorization root.
