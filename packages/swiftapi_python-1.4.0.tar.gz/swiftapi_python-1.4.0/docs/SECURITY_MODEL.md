# Security model

For a mediated capability, verification failure means no authorized execution.
The registered broker fixes the operation, canonical parameters, state, condition,
and trusted key. It rejects forged, expired, replayed, or mismatched grants and
claims permission durably before the side effect. No semantic classifier grants
permission. No model text or empty output is an authority credential.

The marker operation uses exclusive creation and no-follow flags and refuses
paths or overwrites. Generic callback guards assume trusted code accurately
implements the declared action. External-service adapters must own their write
credentials and perform their actual mutation inside this boundary. Giving an
agent the same raw credentials provides an alternate route outside enforcement.

MCP and instructions are integrations. Hooks, sandboxing and permission controls
are host features with their own limits. This installer changes none of them.
An unrestricted same-user/root process can reach local authority keys and state;
production isolation is a deployment requirement, not something a Python import
magically establishes. The package is beta infrastructure, not a security certification.
