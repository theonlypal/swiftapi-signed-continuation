# Bring your own provider keys

The default local brake performs no provider request and needs no provider keys.
Codex or Claude Code retains its normal configuration and environment, including
OPENAI_API_KEY or ANTHROPIC_API_KEY when those are used. The installer never copies
keys into agent instructions, receipt payloads, or its MCP registration.

LOCAL/BYOK: the agent connects directly to its provider; proposed consequences
flow through the capability broker and local or explicitly configured authority.
Existing OpenAI/Anthropic compatibility wrappers are optional: they send prompts
and action metadata to the legacy authority, and provider credentials only to the
provider. They are not the complete upstream SDK and do not support streaming.

A future attested-provider route is a distinct opt-in deployment mode. This release
does not force proxying or advertise that future service as deployed. Do not put
secrets in action descriptions or arbitrary receipt metadata.
