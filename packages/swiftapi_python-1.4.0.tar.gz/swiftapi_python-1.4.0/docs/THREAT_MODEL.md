# Threat model

Protected: missing permission, altered parameters/state/condition/capability,
invalid signatures, expiry/future timestamps, local cross-process nonce replay,
and attempts to use the bundled marker broker for path traversal or overwrites.
Tests include concurrency, wrong trust keys, duplicate JSON keys, target symlinks,
changed sandbox identity, and failure to persist pre-execution evidence.

Trusted: application and broker code, the operator, configured signer/key channel,
current-state collector, operating system and filesystem, and durable local ledger.
The local deployment does not isolate another process with the same UID from the
signer. Root compromise, code modification, database rollback/deletion, arbitrary
host tools, and raw external credentials outside the broker are outside its guarantee.

Replay protection is at-most-once admission, not transactional exactly-once effects.
A crash after claim may execute zero times; a crash during execution may leave a
partial effect. A lost final receipt is not proof nothing happened. Never automatically
retry a consequence. Use service-native idempotency and transactional state checks
when writing a production capability adapter. Signatures do not prove real-world truth.
