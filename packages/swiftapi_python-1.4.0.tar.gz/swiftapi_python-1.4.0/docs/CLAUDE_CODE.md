# Claude Code integration

Run `swiftapi brake install claude --dry-run` then `swiftapi brake install claude`.
The user-level `mcpServers.swiftapi_brake` entry is merged into `~/.claude.json`.
A delimited guidance block is appended to `~/.claude/CLAUDE.md`. Other servers and
settings are preserved. Restart Claude Code and use ordinary prompts with the
registered sandbox tools. Operator approval remains outside the MCP surface.

`swiftapi brake --agent claude` offers a small input loop that passes the user's
input to the existing Claude CLI. It does not add a second model or proxy provider
keys. Existing host authentication and cost rules apply.

Official [MCP](https://code.claude.com/docs/en/mcp),
[hooks](https://code.claude.com/docs/en/hooks),
[permissions](https://code.claude.com/docs/en/permissions), and
[plugins](https://code.claude.com/docs/en/plugins) were inspected. This package uses
the documented stdio MCP configuration and persistent instructions. It does not
promise to intercept arbitrary Bash, computer-use, or third-party tool calls.
