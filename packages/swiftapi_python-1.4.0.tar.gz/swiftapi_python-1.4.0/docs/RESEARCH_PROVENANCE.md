# Research provenance

The product audit preserves live page snapshots, linked record identities, and
historical package bytes outside the editable SDK tree. Frozen experiments are
not modified or freshly re-executed by this software release.

* Empirical observation: the cross-vendor matrix records 31,430 trials and 11,658
  Void outcomes. DOI 10.5281/zenodo.21696066; follow the research page for its frozen
  definitions, complete denominators, provider surfaces and claim boundaries.
* Cross-script observation: DOI 10.5281/zenodo.21799525, a particular prompt-conditioned
  GPT-5.4 output regime, not a universal semantic or internal-mechanism claim.
* Causal open weights: PCCG-1 and PCCG-2 have separate frozen model/replay records.
  PCCG-2 pins a3b952458a46b5547ba3cec7d03a37b395bed03a on Hugging Face. Its native EOS
  intervention and finite-domain certificate are research results, not this package's
  general-purpose safety guarantee.
* Theory: The Binding Condition for Artificial General Intelligence,
  DOI 10.5281/zenodo.19211116, is a proposed criterion, not an industry standard.
* Protocol: SwiftAPI Attestation Protocol v1.0.0, DOI 10.5281/zenodo.18012025,
  specifies infrastructure; it is not a model behavior experiment.

The current [research library](https://getswiftapi.com/research) and
[PCCG-2 record](https://getswiftapi.com/pccg-2) are the authoritative navigation
surfaces. Product claims map to implementation and tests in PRODUCT_TRUTH_MAP.md.
