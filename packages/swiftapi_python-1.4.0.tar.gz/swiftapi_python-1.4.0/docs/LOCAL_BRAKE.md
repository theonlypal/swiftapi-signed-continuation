# Local Brake

The default home is `~/.local/share/swiftapi`. Override it with `SWIFTAPI_HOME`.
It contains an owner-only Ed25519 key, published verification key, pending requests,
one-use grants, SQLite replay ledger, execution receipts, and an owner-only sandbox.
These are local files. Protect them from untrusted processes and preserve the ledger.

The bundled `write_marker` capability creates an absent basename with exact UTF-8
content (at most 4096 bytes). It does not overwrite, accept paths, run commands,
or hold external service credentials. Sandbox device/inode and target absence
are bound into state. Execution opens the directory and target with no-follow
and exclusive creation flags. A race to create a target cannot overwrite it.

The ledger consumes authorization before the first side effect. A crash can consume
a grant without executing; an I/O failure may leave a partial file. There is no retry
and no exactly-once-completion promise. Inspect ERROR outcomes before further action.
`swiftapi brake uninstall` retains all authorization state and receipts.
