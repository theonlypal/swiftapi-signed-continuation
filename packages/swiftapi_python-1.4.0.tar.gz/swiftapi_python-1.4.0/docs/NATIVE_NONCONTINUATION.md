# Native noncontinuation

Keep model behavior separate from deterministic consequence enforcement.
NATIVE_VOID requires exposed native token IDs with the actual EOS identity.
PROVIDER_VOID denotes successful black-box zero-visible-byte output and preserves
the published V0 (text container, normal stop), V1 (budget stop), V2 (absent text,
normal stop), and VU (unmapped stop) distinctions. Provider stop is not native EOS.

REFUSAL, VISIBLE_SAFE, GATE_BLOCK, AUTHORIZED_EXECUTION, and ERROR are distinct.
Visible output requires an independent safety judgment before VISIBLE_SAFE is used.
Transport failures, safety blocks, and tool-mediated events are not Void outcomes.
Whitespace has bytes. Explicit refusals are not Void even if another field is empty.

The observation helper accepts normalized evidence; callers must preserve and
validate the original provider envelope and cannot infer absent fields as success.
This release does not run native models or claim the generalization of PCCG-2.
The frozen native causal evidence remains at getswiftapi.com/pccg-2.
