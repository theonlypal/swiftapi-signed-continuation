# Remote SwiftAPI

The existing SwiftAPI client calls the deployed legacy /verify and /attest APIs.
Keys and scopes are provisioned separately; the local brake requires neither.
Revocation lookup failures now block paranoid enforcement. Requests use bounded
timeouts, HTTPS, no redirects, and no automatic consequence retries.

RemoteAuthority is an optional protocol client requiring an explicit HTTPS endpoint,
trusted Ed25519 key, token, and timeout. It sends swiftapi.authorization-request/v1
and accepts only a verified swiftapi.decision/v1 response. It supplies synchronous
and async authorization. It never executes the action. Local verification and
replay protection remain mandatory at the broker.

The release does not claim the current swiftapi.ai service implements this new
protocol. There is no fallback that translates an unbound legacy response into a
new capability. Deploy and qualify a compatible authority before using this client.
