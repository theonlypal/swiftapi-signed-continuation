# Verification

Do not accept a verification key merely because the untrusted receipt includes it.
Obtain and pin the key from a trusted channel. Local setup emits public-key.json.
A separate machine can verify the receipt with that public key and this package;
it does not need the signing key or cloud connectivity.

`verify_receipt(receipt, public_key)` authenticates the signed schema and issuer.
`verify_decision(decision, public_key, action, condition, state)` additionally
checks allowed=true, exact fields, issue/expiry timestamps, lifetime ≤3600 seconds,
nonce format, and all action/state/condition bindings. Execution then atomically
claims the issuer/nonce pair. Merely calling the signature verifier does not consume
permission or establish that an action ran.

Legacy verify_signature remains an offline verifier for the existing SwiftAPI
attestation protocol, with the published key. is_valid catches verification errors
and returns false. Online revocation belongs to Enforcement(paranoid=True).
