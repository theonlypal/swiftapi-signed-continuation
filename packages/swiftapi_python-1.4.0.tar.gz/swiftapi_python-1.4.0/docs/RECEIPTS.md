# Receipts

`swiftapi.decision/v1` records the authority's authorization decision. A signed
`swiftapi.execution/v1` receipt records a broker attempt and its phase. Denial is
GATE_BLOCK. The authorized_intent receipt precedes execution and has executed=false.
A completed marker write is AUTHORIZED_EXECUTION; execution failures are ERROR.

Every receipt carries an issuer key, exact payload, and Ed25519 signature. Execution
receipts bind a request ID, action hash, and decision hash. Receipt files use random
identifiers and exclusive owner-only writes. The release makes no append-only-log
or external transparency guarantee; the local owner can delete files. A signed
receipt authenticates the issuer's statement, not an independently observed effect.

`swiftapi receipts` lists and verifies local receipts. `swiftapi verify FILE
--public-key KEY_FILE` verifies offline using an explicitly provided trusted key.
Receipt signature checks remain useful after expiry; executing a Decision additionally
requires its time window, exact bindings, and a fresh nonce in the durable ledger.
