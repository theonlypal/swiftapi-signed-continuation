# Action envelopes

ActionEnvelope contains capability, params, intent, and actor. Its SHA-256 digest
covers all four fields. The v1 encoding is UTF-8 JSON with sorted string keys,
compact separators, exact Unicode, booleans/null, lists, and integers within
±(2^53−1). Floats, tuples, NaN/infinity, duplicate parsed keys, surrogate strings,
nonstring object keys, excessive nesting, and envelopes over 2 MiB are rejected.
This is an explicit JSON subset, not a general RFC 8785 implementation.

A Decision binds action_hash, capability, state_hash, condition_hash, nonce,
issued_at and expires_at. State is separately hashed. The trusted broker constructs
both the action and the actual operation from the same detached snapshot. A
changed target, content, actor, intent, capability, or state invalidates the grant.
The legacy cloud fingerprint format remains unchanged for interoperability and
is documented separately in MIGRATION_1_2_2.md.
