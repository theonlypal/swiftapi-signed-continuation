# Codex integration

Run `swiftapi brake install codex --dry-run`, inspect the proposed changes, then
`swiftapi brake install codex`. The installer adds `mcp_servers.swiftapi_brake` to
the user config and a delimited instruction block to `~/.codex/AGENTS.md`.
It points at the installing interpreter (keep that environment installed), backs
up changed files privately, and preserves unrelated configuration. A global
AGENTS.override.md is reported because it would supersede the added guidance.

Restart Codex. Ask normally to use Swift Brake's sandbox; it discovers status,
propose_marker, execute, and read_marker. Approve a request in an operator terminal.
`swiftapi doctor` reports static registration, not proof of a live model/tool call.
`swiftapi brake uninstall codex` removes only unchanged owned entries.

Official mechanisms checked for this release:
[MCP](https://developers.openai.com/codex/mcp/),
[AGENTS.md](https://developers.openai.com/codex/guides/agents-md/),
[skills](https://developers.openai.com/codex/skills/),
[hooks](https://developers.openai.com/codex/hooks/),
[security](https://developers.openai.com/codex/security/).
Hooks exist but require host trust and have incomplete tool coverage. This adapter
uses MCP plus instructions and does not change hooks, permissions, or sandbox settings.

An older separately installed Swift Brake prototype may gate even this server's
read-only MCP calls. This installer preserves that gate. Coordinate exact test-call
authorization with the operator rather than disabling it. `SWIFTAPI_CONFIG_HOME`
selects an isolated configuration home for installer tests; ordinary installation
uses the user's real home. Configuration presence is not runtime qualification.
