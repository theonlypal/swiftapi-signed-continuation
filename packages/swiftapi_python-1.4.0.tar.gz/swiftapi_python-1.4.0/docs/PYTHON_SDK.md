# Python SDK

Legacy imports remain: SwiftAPI, Enforcement, enforce, OpenAI, Anthropic,
verify_signature, is_valid, get_public_key, existing exceptions and UX helpers.
Use `SwiftAPI(key=...)` with `Enforcement(api, paranoid=True)` for scoped legacy
remote authority access. Account issuance is separate from local use.

The README's local example is executed by tests. Construct ActionEnvelope and
BindingCondition, obtain a Decision from LocalAuthority, and use LocalGuard.run.
The callback is invoked only after signature, time, action, condition, and state
verification and durable nonce claim. The callback itself is trusted application
code: it must implement the declared action and must not capture mutable unbound
parameters. Prefer the registered CapabilityBroker when serving an untrusted agent.

The local path is synchronous and makes no network call. RemoteAuthority supplies
`authorize` and `authorize_async`; cancellation of the async wrapper does not cancel
the in-flight HTTP authorization request, but neither method executes consequences.
No consequential execution is retried. BrakeError subclasses include InvalidEnvelope,
AuthorizationDenied, and ReplayError. Legacy exception imports are preserved.
