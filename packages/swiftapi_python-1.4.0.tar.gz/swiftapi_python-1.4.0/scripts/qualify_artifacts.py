"""Install each distribution in a clean venv; retain every log and qualification."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import venv


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dist", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.dist = args.dist.resolve()
    args.output = args.output.resolve()
    args.output.mkdir(parents=True, exist_ok=False)
    artifacts = sorted(args.dist.glob("*.whl")) + sorted(args.dist.glob("*.tar.gz"))
    if len(artifacts) != 2:
        raise RuntimeError("Exactly one wheel and one sdist required")
    results = []
    for artifact in artifacts:
        kind = "wheel" if artifact.suffix == ".whl" else "sdist"
        base = args.output / kind
        base.mkdir()
        envdir = base / "venv"
        venv.EnvBuilder(with_pip=True).create(envdir)
        python = envdir / "bin/python"
        command = envdir / "bin/swiftapi"
        env = os.environ.copy()
        env.pop("PYTHONPATH", None)
        env.pop("PYTHONHOME", None)
        env["SWIFTAPI_HOME"] = str(base / "local-state")
        env["SWIFTAPI_CONFIG_HOME"] = str(base / "config-home")
        (base / "config-home/.codex").mkdir(parents=True)
        log = []

        def run(name, argv):
            r = subprocess.run(
                [str(a) for a in argv],
                cwd=base,
                env=env,
                capture_output=True,
                text=True,
                timeout=300,
            )
            (base / (name + ".stdout")).write_text(r.stdout)
            (base / (name + ".stderr")).write_text(r.stderr)
            log.append({"name": name, "returncode": r.returncode})
            if r.returncode:
                raise RuntimeError(name + " failed; inspect " + str(base))
            return r.stdout

        run("install", [python, "-m", "pip", "install", "--disable-pip-version-check", artifact])
        run(
            "import",
            [
                python,
                "-c",
                'import swiftapi,sys,pathlib; assert pathlib.Path(sys.prefix) in pathlib.Path(swiftapi.__file__).parents; assert swiftapi.__version__ == "1.3.1"; print(swiftapi.__file__)',
            ],
        )
        run("doctor", [command, "doctor"])
        run("dry-run", [command, "brake", "install", "--dry-run"])
        report = json.loads(
            run("qualification", [command, "brake", "test", "--output", base / "qualification"])
        )
        if report["status"] != "PASS":
            raise RuntimeError("Qualification failed")
        for i, path in enumerate(report["receipts"]):
            run(
                "verify-" + str(i),
                [command, "verify", path, "--public-key", base / "qualification/public-key.json"],
            )
        run("dependencies", [python, "-m", "pip", "freeze", "--all"])
        results.append(
            {
                "kind": kind,
                "artifact": artifact.name,
                "sha256": hashlib.sha256(artifact.read_bytes()).hexdigest(),
                "checks": log,
                "qualification": report,
                "python": sys.version,
                "status": "PASS",
            }
        )
        (args.output / "report.json").write_text(
            json.dumps({"status": "IN_PROGRESS", "artifacts": results}, indent=2)
        )
    (args.output / "report.json").write_text(
        json.dumps({"status": "PASS", "artifacts": results}, indent=2)
    )
    print(
        json.dumps(
            {
                "status": "PASS",
                "artifacts": [{"kind": r["kind"], "sha256": r["sha256"]} for r in results],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
