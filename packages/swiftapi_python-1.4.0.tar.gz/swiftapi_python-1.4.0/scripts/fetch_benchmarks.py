"""Fetch pinned framework source trees only. Does not execute their code or models."""

import argparse
import json
from pathlib import Path
import subprocess


def main():
    p = argparse.ArgumentParser()
    p.add_argument("output", type=Path)
    args = p.parse_args()
    lock = json.loads(
        (Path(__file__).resolve().parents[1] / "benchmarks/sources.lock.json").read_text()
    )
    args.output.mkdir(parents=True, exist_ok=False)
    for name, entry in lock.items():
        target = args.output / name
        subprocess.run(["git", "init", str(target)], check=True, capture_output=True)
        subprocess.run(
            [
                "git",
                "-C",
                str(target),
                "fetch",
                "--depth",
                "1",
                entry["repository"],
                entry["revision"],
            ],
            check=True,
            capture_output=True,
        )
        subprocess.run(
            ["git", "-C", str(target), "checkout", "--detach", "FETCH_HEAD"],
            check=True,
            capture_output=True,
        )
        actual = subprocess.check_output(
            ["git", "-C", str(target), "rev-parse", "HEAD"], text=True
        ).strip()
        if actual != entry["revision"]:
            raise RuntimeError("Revision mismatch")
        print(name + " " + actual)


if __name__ == "__main__":
    main()
