"""Download exact upstream corpus bytes and verify every pinned hash; no model calls."""

import argparse
import hashlib
import json
from pathlib import Path
import urllib.request


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    lock = json.loads(
        (Path(__file__).resolve().parents[1] / "benchmarks/corpora.lock.json").read_text()
    )
    for name, entry in lock.items():
        with urllib.request.urlopen(entry["url"], timeout=30) as response:
            data = response.read(16 * 1024 * 1024)
        if hashlib.sha256(data).hexdigest() != entry["sha256"]:
            raise RuntimeError("Corpus hash mismatch: " + name)
        (args.output / (name + ".csv")).write_bytes(data)
        print(name + " " + entry["sha256"])


if __name__ == "__main__":
    main()
