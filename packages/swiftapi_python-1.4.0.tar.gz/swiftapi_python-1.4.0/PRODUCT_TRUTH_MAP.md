# Product truth map — 2026-09-22

Source record: live getswiftapi.com pages fetched before code mutation, linked
DOIs/repositories followed, exact PyPI 1.2.2 wheel/sdist verified. Audit snapshots
and source reconciliation are retained in the enclosing consolidation/audit tree.
Status distinguishes implementation from research and protocol claims; a source
inspection is not a fresh replay of frozen research or a production service audit.

| Claim / category | Website location | Implementation | Test / evidence / immutable identity | Current status |
| --- | --- | --- | --- | --- |
| Native EOS-only content/permission separation, 101 parameters | /, /pccg-2, /research | Frozen research model, not this SDK | HF PCCG-2 revision a3b952458a46b5547ba3cec7d03a37b395bed03a; DOI 22730710; 2048 FINAL, 40+40 causal, frozen non-EOS hash 5f42fcb08c73af4914a711b524ae7130d671ec9504ecdfa699e8f478094713ec | RESEARCH_ONLY |
| Full accepted six-digit domain certificate | /pccg-2 | Published finite-precision proof/checker, not 810 billion new trials | DOI 22730710 manuscript supplement; specific recorded-content and arithmetic assumptions | RESEARCH_ONLY |
| PCCG-1 reasoning-prefix-preserving GO/EOS intervention | /pccg, /research | Separate trained Qwen3-4B release | GitHub d08b157ac9273974b75d7ada2a894a1afe86e3f2; HF 5f3b70d51f068a7a8a108b99f66b2fdfd15e25ce; DOI 22681787 | RESEARCH_ONLY |
| 31,430-trial matrix, 11,658 Void outcomes, 0/4290 matched control Voids | /, /research | Frozen provider records, not a universal security guarantee | DOI 21696066; void-matrix-complete-analysis v1.0.0-evidence-analysis; published definition retained | RESEARCH_ONLY |
| 12,160 cross-script trials, 7253 exact artifacts | /, /research | Frozen GPT-5.4 records | DOI 21799525; gpt-5.4-shrt-cross-script-evidence | RESEARCH_ONLY |
| Earlier 180/180 null trials with non-null controls | /research | Frozen two-model protocol | DOI 18976656; void-convergence repository | RESEARCH_ONLY |
| Kimi native/provider receipt terminology | /kimi-receipts | Public case evidence and receipt verifier | Linked captured provider records; no inference of internal EOS from stop | RESEARCH_ONLY |
| Binding condition / proposed AGI criterion | /research, /public-agi-criterion | Conceptual criterion, not a software security proof | DOI 19211116 | DOCUMENTED_ONLY |
| Textual emergence, earlier frameworks and chronology | /research | Published research history | DOIs 17856031, 18395519, 18750330, 18796600; links preserved | RESEARCH_ONLY |
| Attestation protocol, offline Ed25519 verification | /docs, /verify, /research | legacy verifier.py; brake/core.py | test_verifier.py; test_brake.py; DOI 18012025; pinned historical key | IMPLEMENTED |
| Revocation and replay defense advertised for SDK | /, /docs | client.check_revocation; Enforcement; verifier.claim_attestation | test_legacy_security.py; test_release_contract.py; historical revocation failed open and lacked local replay, corrected here | IMPLEMENTED |
| No action executes without verification | historical PyPI README; /docs | Enforcement callbacks and registered broker only | Forged/mismatched/replay tests; wording narrowed to mediated capabilities, no arbitrary-root guarantee | PARTIAL |
| Scoped keys, policies, grants, audit endpoints | /, /docs | existing backend main.py routes and legacy SDK client | Backend source inspected; no authenticated production write was performed | PARTIAL |
| API/proxy/admission/runtime integrations | /docs | existing backend, CLI/MCP and admission-controller trees | Existing code present; not all runtime deployments qualified in this release | PARTIAL |
| Public self-service cloud key issuance unavailable | /docs | Existing scoped authority provisioning flow | Live documentation explicitly states scoped evaluation/partnership access; local package requires no account | DOCUMENTED_ONLY |
| BYOK/provider credentials remain with provider | /docs | existing compatibility wrappers; new MCP path has no provider request | test_openai.py, test_anthropic.py, HTTPS/no-redirect regressions; no live provider call required | IMPLEMENTED |
| Optional attested-provider service mode | new BYOK documentation | Existing legacy attestation wrappers; no forced provider proxy | Service-specific new mode not deployed by this release | DOCUMENTED_ONLY |
| Local prerequisite-conditioned brake | new /brake, README | brake/core.py, broker.py, cli.py | 11-case local qualification plus adversarial/property tests | IMPLEMENTED |
| Canonical action/state/condition binding | new product docs | ActionEnvelope, BindingCondition, verify_decision | Hash substitution, type sensitivity, mutation and serialization property tests | IMPLEMENTED |
| Signed short-lived one-use authorization | new product docs | LocalAuthority, ReplayLedger | Forgery, wrong trust key, expiry, concurrency and fresh-process replay tests | IMPLEMENTED |
| Durable receipts independently verified | new /brake | decision/execution schemas and CLI verify | Signed-envelope verification in isolated process; no assertion that signature proves real-world effect | IMPLEMENTED |
| Codex/Claude normal prompts with local tools | new /brake | stdio MCP, managed config and instruction installers | Installer preservation/reversal tests; live host qualification reported separately in release manifest | IMPLEMENTED |
| Hooks form universal security boundary | not a valid supported claim | No mandatory-hook claim in this release | Official host docs identify coverage/trust limits; arbitrary tools remain outside broker | STALE |
| Native model runtime as installable 2.0.0 product | local unpublished /void draft; live /void returns 404 | Unpublished home SDK work preserved separately | Missing public release manifest; isolated website safely returns 404 until a qualified release exists | MISSING |
| Defensive benchmark adapter | new benchmark docs | brake/benchmarks.py and pinned upstream fetch script | Case-denominator and failure-retention tests; frameworks fetched at exact locked commits; model evaluations not run | IMPLEMENTED |
| Zero unauthorized escape in production | requested invariant, no universal public result | Enforced for broker requests under documented trust assumptions | Local fixture escape count only; production adapters/credential isolation require qualification | PARTIAL |
| Patent filing record | /patent | Public record and document links only | No legal scope, validity, or enforcement inference made by SDK release | DOCUMENTED_ONLY |

All bare DOI numbers above are under `10.5281/zenodo.`. The full URLs and page
responses are in the audit index. The archived matrix ZIP fetch is explicitly
marked as a retained prefix, not a complete evidence re-verification.

## Source reconciliation

The historical import/API tree was compared byte-for-byte with both local SDKs.
The isolated release starts from the verified 1.2.2 sdist, retains an ancestor
commit, imports inspected compatible security fixes from the home SDK, and adds
the deterministic local brake. The unpublished native 2.0.0 tree, Swift Brake
prototype, backend, research assets and dirty website source remain untouched.
Website changes are isolated and reviewable in a separate checkout and patch.
