# Changelog

## 1.3.1 — 2026-09-22

Fix package-index README guide links by pointing to the public source distribution
and documentation. Runtime behavior is unchanged from 1.3.0; version reporting
identifies this patch. Historical distributions remain immutable.

## 1.3.0 — 2026-09-22

Add local prerequisite evaluation, canonical action envelopes, Ed25519 decisions
and execution receipts, durable replay protection, an exact sandbox marker broker,
Codex/Claude MCP installation with dry-run/backups/uninstall, and local qualification.
Add an optional pinned-key remote decision client with sync and async authorization.
Add pinned defensive-framework fetches and denominator-preserving evaluation import.

Harden inherited authority and provider paths: verify signed exact-action approval,
consume attestations before consequences, refuse redirects, fail closed on unknown
revocation, and preserve provider termination metadata without synthetic Void labels.

Research artifacts, native-EOS model claims, and unpublished local 2.0 work are
preserved separately. This release does not claim to reproduce or ship those models.

## 1.2.2 — 2026-02-25

Historical PyPI ancestor. Its wheel and sdist are immutable; the release audit
records their published and independently recomputed hashes and exact public API.
