# Native receipt support in 1.4.0

This package adds a loopback native-EOS client and an offline receipt verifier.
It does not contain model weights or run an inference service by itself.
Existing 1.3.1 calls retain their behaviour. `PolicyViolation` still raises;
`response`, `raw_response`, and `status_code` now preserve a denied response.

```python
from swiftapi.native import NativeEOSClient
from swiftapi.native_verify import verify_receipt

with NativeEOSClient(key, base_url="http://127.0.0.1:8765") as client:
    response = client.generate("What is 2 + 2?", request_id=request_id)

report = verify_receipt(
    receipt_path,
    trusted_runtime_public_key,
    "RECORDED_LOGITS_REPLAY",
    expected_max_grant_age_seconds=60,
)
```

The runtime public key and expected age must come from the independently
approved protocol, not from the receipt being checked. The default authority
public key is SwiftAPI's pinned production key. Test-authority receipts require
an explicitly supplied test public key and are reported as non-production.

```sh
python -m swiftapi.native_verify receipt.json \
  --trusted-key runtime-public.json \
  --expected-mode RECORDED_LOGITS_REPLAY \
  --expected-max-grant-age-seconds 60
```

The verifier checks the runtime signature, authority signatures and request
binding, every declared asset hash, stored BF16 vector lengths and non-EOS
identity, greedy argmax, raw input/output binding, completion scope and the
frozen July 29 class. It needs neither torch nor model files nor signing keys.
It does not independently reproduce a model forward pass, attest hardware,
authenticate an unsigned revocation observation, or prove runtime honesty.

Receipt schema controls compatibility; the declared SDK version is reported,
not a fixed acceptance gate. `native_classifier_releases.py` retains known
classifier hashes. The declared classifier must be in that registry and must
agree with the SDK identity recorded in the receipt. Class, classification
fields and completion scope are recomputed separately. A later non-semantic
source edit does not invalidate earlier classifier hashes.

The native output field is always present. A completed zero-byte native EOS
stop is V0. A replayed nonempty first token is R with
`FIRST_TOKEN_ONLY_NOT_A_COMPLETE_ANSWER`, never a complete generated answer.
Rejections before decoding are operational, not Voids.

Package status: local release candidate, not uploaded to PyPI.
