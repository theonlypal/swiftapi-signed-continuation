"""
SwiftAPI Attested Anthropic - Compatibility wrapper.

    # Before (vibe coding):
    from anthropic import Anthropic
    client = Anthropic(api_key="sk-ant-...")

    # After (attested):
    from swiftapi import Anthropic
    client = Anthropic(swiftapi_key="swiftapi_live_...", anthropic_key="sk-ant-...")

Compatibility wrapper for the documented nonstreaming text subset. Authorization is attested.
Provider keys are sent only to the provider. This wrapper does not establish native EOS.
"""

import requests
from typing import List, Dict, Optional, Any

from . import __version__
from .exceptions import SwiftAPIError, AuthenticationError, NetworkError
from .verifier import (
    verify_signature,
    claim_attestation,
    _action_fingerprint,
    _snapshot_action_data,
    _validate_action_binding,
)


class ContentBlock:
    """Anthropic-compatible content block."""

    def __init__(self, text: str, type: str = "text"):
        self.text = text
        self.type = type

    def __repr__(self):
        truncated = self.text[:80] if self.text else ""
        return f"ContentBlock(type='{self.type}', text='{truncated}')"


class MessageResponse:
    """Anthropic-compatible message response."""

    def __init__(
        self,
        content: str,
        model: str,
        role: str = "assistant",
        stop_reason: str = None,
        attested: bool = False,
        jti: str = None,
    ):
        self.content = [ContentBlock(text=content)] if content else [ContentBlock(text="")]
        self.model = model
        self.role = role
        self.stop_reason = stop_reason
        self.classification = "GATE_BLOCK" if not attested else "UNCLASSIFIED_PROVIDER_OUTPUT"
        self.native_eos_verified = False
        self.attested = attested
        self.jti = jti

    @property
    def text(self):
        """Convenience: response.text instead of response.content[0].text"""
        return self.content[0].text if self.content else ""


class Messages:
    """Handles messages.create() calls."""

    def __init__(self, swiftapi_key: str, anthropic_key: str, authority_url: str, timeout: int):
        self._swiftapi_key = swiftapi_key
        self._anthropic_key = anthropic_key
        from urllib.parse import urlparse
        parsed = urlparse(authority_url)
        if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise SwiftAPIError("Authority URL must use HTTPS without embedded credentials")
        self._authority_url = authority_url.rstrip("/")
        self._timeout = timeout
        self._session = requests.Session()

    def create(
        self,
        model: str,
        messages: List[Dict[str, Any]],
        max_tokens: int = 1024,
        temperature: Optional[float] = None,
        system: Optional[str] = None,
        **kwargs,
    ) -> MessageResponse:
        """
        Create an attested message completion.

        Same interface as anthropic.messages.create().
        Step 1: Attest with SwiftAPI (governance).
        Step 2: Call Anthropic directly with your key (execution).

        If governance denies, content is empty and classification is GATE_BLOCK.

        Args:
            model: Model name (e.g. "claude-sonnet-4-5-20250929")
            messages: List of message dicts with role and content
            max_tokens: Max tokens in response
            temperature: Sampling temperature
            system: System prompt

        Returns:
            MessageResponse with .content[0].text
        """
        payload = {
            "model": model,
            "messages": messages,
            "max_tokens": max_tokens,
        }
        if temperature is not None:
            payload["temperature"] = temperature
        if system is not None:
            payload["system"] = system
        if kwargs.get("stream"):
            raise SwiftAPIError("Streaming is unsupported by this compatibility wrapper")
        payload.update(kwargs)
        payload = _snapshot_action_data(payload)
        expected_fingerprint = _action_fingerprint(payload, truncated=True)

        # Step 1: Attest with SwiftAPI — governance check
        try:
            attest_resp = self._session.post(
                f"{self._authority_url}/attest",
                json={"action_type": "chat_completion", "action_data": payload},
                headers={
                    "X-SwiftAPI-Authority": self._swiftapi_key,
                    "Content-Type": "application/json",
                    "User-Agent": f"swiftapi-python/{__version__}",
                },
                timeout=self._timeout,
                allow_redirects=False,
            )
        except requests.exceptions.RequestException:
            raise NetworkError("Attestation request failed") from None

        if attest_resp.status_code == 403:
            raise AuthenticationError("Invalid SwiftAPI authority key")
        if attest_resp.status_code == 429:
            raise SwiftAPIError("Rate limit exceeded")
        if attest_resp.status_code != 200:
            raise SwiftAPIError("Attestation failed")

        attestation = attest_resp.json()
        verify_signature(attestation)
        if not _validate_action_binding(attestation, "chat_completion", expected_fingerprint):
            return MessageResponse(content="", model=model)

        claim_attestation(attestation)

        # Step 2: Call Anthropic directly — user's own key, user's own credits
        anthropic_payload = payload

        try:
            anthropic_resp = self._session.post(
                "https://api.anthropic.com/v1/messages",
                json=anthropic_payload,
                headers={
                    "x-api-key": self._anthropic_key,
                    "anthropic-version": "2023-06-01",
                    "Content-Type": "application/json",
                    "User-Agent": f"swiftapi-python/{__version__}",
                },
                timeout=self._timeout,
                allow_redirects=False,
            )
        except requests.exceptions.RequestException:
            raise NetworkError("Anthropic request failed") from None

        if anthropic_resp.status_code == 401:
            raise AuthenticationError("Invalid Anthropic API key")
        if anthropic_resp.status_code != 200:
            raise SwiftAPIError("Anthropic error")

        data = anthropic_resp.json()
        content_blocks = data.get("content", [])
        text = content_blocks[0].get("text", "") if content_blocks else ""

        result = MessageResponse(
            content=text,
            model=model,
            role=data.get("role", "assistant"),
            stop_reason=data.get("stop_reason"),
            attested=True,
            jti=attestation.get("jti"),
        )
        result.raw_response = data
        return result


class Anthropic:
    """
    Compatibility wrapper for anthropic.Anthropic.

    Every completion is cryptographically attested via SwiftAPI.
    SwiftAPI governs. Anthropic executes. You bring both keys.

    Usage:
        from swiftapi import Anthropic

        client = Anthropic(
            swiftapi_key="swiftapi_live_...",
            anthropic_key="sk-ant-..."
        )
        r = client.messages.create(
            model="claude-sonnet-4-5-20250929",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello"}]
        )
        print(r.content[0].text)
    """

    def __init__(
        self,
        swiftapi_key: str = None,
        anthropic_key: str = None,
        api_key: str = None,
        authority_url: str = "https://swiftapi.ai",
        timeout: int = 60,
        **kwargs,
    ):
        if not swiftapi_key:
            raise AuthenticationError("swiftapi_key is required")
        if not swiftapi_key.startswith("swiftapi_live_"):
            raise AuthenticationError("Invalid key format: must start with 'swiftapi_live_'")

        ant_key = anthropic_key or api_key
        if not ant_key:
            raise AuthenticationError("anthropic_key is required (your Anthropic API key)")

        self.messages = Messages(swiftapi_key, ant_key, authority_url, timeout)
