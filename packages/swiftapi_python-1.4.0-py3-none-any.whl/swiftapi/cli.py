"""SwiftAPI command-line entry point. Local first, no hidden provider calls."""

from __future__ import annotations
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from . import __version__
from .brake import CapabilityBroker, verify_receipt
from .brake.core import loads
from .brake.install import install, uninstall, doctor
from .brake.qualification import qualify


def interactive(agent: str) -> int:
    executable = shutil.which(agent)
    if executable is None:
        raise ValueError(agent + " is not installed")
    print(
        "SwiftAPI · "
        + agent
        + " supplies cognition; SwiftAPI gates its registered sandbox capability."
    )
    print(
        "Type ordinary input; /status, /test, /quit are local commands. Host calls use your existing account."
    )
    while True:
        try:
            prompt = input("swiftapi> ")
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        if prompt.strip() in ("/quit", "/exit"):
            return 0
        if prompt.strip() == "/status":
            print(json.dumps(CapabilityBroker().status(), indent=2))
        elif prompt.strip() == "/test":
            print(json.dumps(qualify(Path(tempfile.mkdtemp(prefix="swiftapi-test-"))), indent=2))
        elif prompt.strip():
            # No extra model, altered system prompt, provider proxy or output filtering.
            command = (
                [executable, "exec", "--skip-git-repo-check", "-"]
                if agent == "codex"
                else [executable, "-p"]
            )
            subprocess.run(command, input=prompt, text=True, check=False)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="swiftapi", description="Local prerequisite-conditioned consequence enforcement"
    )
    parser.add_argument("--version", action="version", version=__version__)
    sub = parser.add_subparsers(dest="command")
    sub.add_parser("doctor", help="Inspect local package and host registration")
    sub.add_parser("status", help="Show broker scope and pending requests")
    sub.add_parser("receipts", help="List local signed execution receipts")
    verify = sub.add_parser(
        "verify", help="Verify a receipt against an independently trusted public key"
    )
    verify.add_argument("receipt", type=Path)
    verify.add_argument(
        "--public-key", required=True, type=Path, help="JSON file containing public_key"
    )
    sub.add_parser("mcp", help="Run stdio MCP broker")
    brake = sub.add_parser("brake", help="Interactive host input or local brake operations")
    brake.add_argument("--agent", choices=("codex", "claude"), default="codex")
    bsub = brake.add_subparsers(dest="operation")
    for name in ("install", "uninstall"):
        p = bsub.add_parser(name)
        p.add_argument("host", nargs="?", choices=("codex", "claude"))
        p.add_argument("--dry-run", action="store_true")
    p = bsub.add_parser("test")
    p.add_argument("--output", type=Path)
    p = bsub.add_parser("propose")
    p.add_argument("name")
    p.add_argument("content")
    p = bsub.add_parser("authorize")
    p.add_argument("request_id")
    p.add_argument("--ttl", type=int, default=300)
    p = bsub.add_parser("execute")
    p.add_argument("request_id")
    p = bsub.add_parser("read")
    p.add_argument("name")
    args = parser.parse_args(argv)
    try:
        if args.command == "doctor":
            value = doctor()
        elif args.command == "verify":
            value = verify_receipt(
                loads(args.receipt.read_bytes()), loads(args.public_key.read_bytes())["public_key"]
            )
        elif args.command == "mcp":
            from .brake.mcp import serve

            serve()
            return 0
        elif args.command == "brake":
            if args.operation is None:
                return interactive(args.agent)
            if args.operation in ("install", "uninstall"):
                value = (install if args.operation == "install" else uninstall)(
                    args.host, args.dry_run
                )
            elif args.operation == "test":
                output = args.output or Path(tempfile.mkdtemp(prefix="swiftapi-qualification-"))
                value = qualify(output)
            elif args.operation == "propose":
                value = CapabilityBroker().propose(args.name, args.content)
            elif args.operation == "authorize":
                value = CapabilityBroker().authorize(args.request_id, args.ttl)
            elif args.operation == "execute":
                value = CapabilityBroker().execute(args.request_id)
            else:
                value = CapabilityBroker().read_marker(args.name)
        elif args.command == "status":
            value = CapabilityBroker().status()
        elif args.command == "receipts":
            broker = CapabilityBroker()
            value = [
                {"path": str(p), "payload": broker.verify(p)}
                for p in sorted(broker.receipts.glob("*.json"))
            ]
        else:
            parser.print_help()
            return 0
        print(json.dumps(value, indent=2, ensure_ascii=False))
        # A valid denial receipt is still a successfully verified signature.
        if args.command == "verify":
            return 0
        return (
            1
            if isinstance(value, dict)
            and (
                value.get("status") == "FAIL"
                or value.get("classification") in {"GATE_BLOCK", "ERROR"}
            )
            else 0
        )
    except Exception as exc:
        print(
            json.dumps(
                {"classification": "ERROR", "error": type(exc).__name__, "message": str(exc)}
            ),
            file=sys.stderr,
        )
        return 1
