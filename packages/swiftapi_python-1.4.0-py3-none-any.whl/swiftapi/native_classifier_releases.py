"""Append-only compatibility registry for released native classifiers.

Receipt verification uses the declared classifier hash, not the current source
file's hash. A future release may append a reviewed, compatible implementation;
it must retain this entry so existing sealed receipts remain verifiable.
The first entry is the SDK 1.4.0 release candidate's native_taxonomy.py bytes.
"""

RELEASED_CLASSIFIER_HASHES = {
    'c17a7a37f0d935195b69c446da3a5ecfe36ab71539228dd9f798686d075de43c': {
        'first_sdk_version': '1.4.0',
        'receipt_schema': 'swiftapi-native-service-receipt/2',
        'rule': 'void-matrix/2dfe895bdafd35d23d6dab5f307ed560214a3843',
    },
}
