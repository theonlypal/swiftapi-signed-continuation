"""Import externally judged defensive evaluations without copying their corpora.

Rows must carry immutable framework/corpus identities and explicit executor
observations. This adapter does not infer safety, authority, or escape from text.
"""

from __future__ import annotations
from collections import Counter
from pathlib import Path
from typing import Iterable
from .core import InvalidEnvelope, digest, loads, write_exclusive
from .observations import CLASSES

FRAMEWORKS = {"JailbreakBench", "HarmBench", "StrongREJECT"}


def summarize(rows: Iterable[dict], expected_ids: Iterable[str]) -> dict:
    ids = list(expected_ids)
    if not ids or len(ids) != len(set(ids)):
        raise InvalidEnvelope("Expected unique nonempty benchmark case IDs")
    results = list(rows)
    seen = []
    counts: Counter = Counter()
    failures = []
    for row in results:
        required = {
            "case_id",
            "framework",
            "revision",
            "corpus_sha256",
            "classification",
            "authorized",
            "consequence_observed",
            "evidence_sha256",
        }
        if (
            not required <= set(row)
            or row["framework"] not in FRAMEWORKS
            or row["classification"] not in CLASSES
        ):
            raise InvalidEnvelope("Missing framework, evidence or outcome fields")
        for field, size in (("revision", 40), ("corpus_sha256", 64), ("evidence_sha256", 64)):
            v = row[field]
            if type(v) is not str or len(v) != size or any(c not in "0123456789abcdef" for c in v):
                raise InvalidEnvelope("Immutable source and evidence hashes required")
        if type(row["authorized"]) is not bool or type(row["consequence_observed"]) is not bool:
            raise InvalidEnvelope("Explicit independent execution observations required")
        seen.append(row["case_id"])
        counts[row["classification"]] += 1
        if row["consequence_observed"] and not row["authorized"]:
            failures.append(row)
    if len(seen) != len(set(seen)) or set(seen) != set(ids):
        raise InvalidEnvelope("Missing, duplicate, or unexpected cases; denominator cannot change")
    return {
        "schema": "swiftapi.benchmark/v1",
        "total": len(ids),
        "counts": dict(counts),
        "unauthorized_consequential_escapes": len(failures),
        "status": "FAIL" if failures or counts["ERROR"] else "PASS",
        "failures": failures,
        "rows_sha256": digest(results),
        "results": results,
    }


def import_results(source: Path, output: Path, expected_ids: list) -> dict:
    """Preserve all supplied rows. Output must be new; failures remain regressions."""
    rows = [loads(line) for line in source.read_bytes().splitlines() if line.strip()]
    report = summarize(rows, expected_ids)
    write_exclusive(output, report)
    return report


def load_cases(framework: str, corpus: Path, expected_sha256: str) -> list:
    """Read original upstream CSV bytes after pin verification; never rewrite corpora."""
    import csv
    import hashlib
    import io

    if framework not in FRAMEWORKS:
        raise InvalidEnvelope("Unknown framework")
    raw = corpus.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise InvalidEnvelope("Corpus hash mismatch")
    rows = list(csv.DictReader(io.StringIO(raw.decode("utf-8-sig"))))
    mappings = {
        "JailbreakBench": ("Goal", "Behavior", "Category"),
        "HarmBench": ("Behavior", "BehaviorID", "SemanticCategory"),
        "StrongREJECT": ("forbidden_prompt", None, "category"),
    }
    prompt, identifier, category = mappings[framework]
    result = []
    for index, row in enumerate(rows):
        if prompt not in row or category not in row or (identifier and identifier not in row):
            raise InvalidEnvelope("Unexpected upstream corpus columns")
        result.append(
            {
                "case_id": framework
                + ":"
                + corpus.stem
                + ":"
                + (row[identifier] if identifier else str(index)),
                "prompt": row[prompt],
                "context": row.get("ContextString", ""),
                "category": row[category],
                "corpus_sha256": expected_sha256,
            }
        )
    if len({r["case_id"] for r in result}) != len(result):
        raise InvalidEnvelope("Duplicate corpus IDs")
    return result
