"""Reversible MCP + instruction installation. Does not alter host permissions."""

from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
from typing import Optional
from .core import InvalidEnvelope, secure_dir, loads

SERVER = "swiftapi_brake"
BEGIN = "# BEGIN SWIFTAPI BRAKE MANAGED"
END = "# END SWIFTAPI BRAKE MANAGED"
GUIDANCE = """# BEGIN SWIFTAPI BRAKE MANAGED
SwiftAPI supplies a local prerequisite gate for its registered capabilities.
Use swiftapi_brake status to discover its sandbox, propose_marker to request an
exact marker, and execute to attempt it. A GATE_BLOCK is a denied tool action,
not model-native silence. Approval is performed by the operator with
`swiftapi brake authorize REQUEST_ID` in a separate terminal. Never self-approve
or edit authority state to bypass a denial. Existing governing instructions
still apply. Arbitrary tools and host shell commands are outside this broker.
Do not send provider keys, credentials, or secrets to the broker or model context.
# END SWIFTAPI BRAKE MANAGED
"""


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _read(path: Path) -> bytes:
    if path.is_symlink() or (path.exists() and not path.is_file()):
        raise InvalidEnvelope("Refusing nonregular configuration: " + str(path))
    return path.read_bytes() if path.exists() else b""


def _atomic(path: Path, data: bytes) -> None:
    _read(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=".swiftapi-", dir=path.parent)
    try:
        mode = path.stat().st_mode & 0o777 if path.exists() else 0o600
        os.fchmod(fd, mode)
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def _toml(data: bytes) -> dict:
    try:
        import tomllib
    except ImportError:
        import tomli as tomllib
    return tomllib.loads(data.decode("utf-8"))


def _hosts(host: Optional[str], home: Path) -> list:
    if host:
        if host not in ("codex", "claude"):
            raise InvalidEnvelope("Supported hosts: codex, claude")
        return [host]
    result = [h for h in ("codex", "claude") if shutil.which(h) or (home / ("." + h)).exists()]
    if not result:
        raise InvalidEnvelope("No host detected; specify codex or claude")
    return result


def install(host: Optional[str] = None, dry_run: bool = False, home: Optional[Path] = None) -> dict:
    home = Path(home or os.environ.get("SWIFTAPI_CONFIG_HOME") or Path.home()).absolute()
    state = home / ".local/state/swiftapi-install"
    python = sys.executable  # Preserve venv executable; resolving it would discard the venv.
    changes = []
    records = []
    for h in _hosts(host, home):
        receipt_path = state / (h + ".json")
        receipt = loads(_read(receipt_path)) if receipt_path.exists() else None
        config = home / (".codex/config.toml" if h == "codex" else ".claude.json")
        instructions = home / (".codex/AGENTS.md" if h == "codex" else ".claude/CLAUDE.md")
        old = _read(config)
        text = _read(instructions)
        entry = {"command": python, "args": ["-m", "swiftapi", "mcp"]}
        fragment = ("\n\n" + GUIDANCE).encode()
        if h == "codex":
            parsed = _toml(old)
            present = parsed.get("mcp_servers", {}).get(SERVER)
            block = (
                "\n"
                + BEGIN
                + "\n[mcp_servers."
                + SERVER
                + "]\ncommand = "
                + json.dumps(python)
                + '\nargs = ["-m", "swiftapi", "mcp"]\n'
                + END
                + "\n"
            ).encode()
            if BEGIN.encode() in old and (not receipt or old.count(block) != 1):
                raise InvalidEnvelope("Unowned/modified managed Codex block")
            new = old if present == entry and receipt else old + block
            _toml(new)
        else:
            parsed = json.loads(old) if old else {}
            if not isinstance(parsed, dict) or not isinstance(parsed.get("mcpServers", {}), dict):
                raise InvalidEnvelope("Invalid Claude configuration")
            present = parsed.get("mcpServers", {}).get(SERVER)
            parsed.setdefault("mcpServers", {})[SERVER] = entry
            # Claude rewrites its own JSON formatting during normal use. If our
            # owned entry is intact, preserve those bytes on repeated installs.
            new = (
                old
                if present == entry and receipt
                else (json.dumps(parsed, indent=2, ensure_ascii=False) + "\n").encode()
            )
            block = b""
        if present is not None and (not receipt or present != receipt["entry"] or present != entry):
            raise InvalidEnvelope(
                "Unowned/modified SwiftAPI MCP entry; uninstall the owned version first"
            )
        if BEGIN.encode() in text:
            if not receipt or text.count(fragment) != 1:
                raise InvalidEnvelope("Unowned/modified instruction block")
            instruction_new = text
        else:
            instruction_new = text + fragment
        if h == "codex" and (home / ".codex/AGENTS.override.md").exists():
            raise InvalidEnvelope(
                "AGENTS.override.md overrides global guidance; resolve it before installing"
            )
        if receipt and receipt.get("status") == "installed":
            if new == old and instruction_new == text:
                changes.append({"host": h, "status": "already installed", "paths": []})
                continue
        records.append(
            (h, config, old, new, instructions, text, instruction_new, entry, block, fragment)
        )
        changes.append(
            {
                "host": h,
                "status": "planned",
                "paths": [str(config), str(instructions)],
                "mcp_entry": entry,
                "instruction_added": GUIDANCE,
            }
        )
    if dry_run:
        return {"dry_run": True, "changes": changes, "host_permissions_changed": False}
    if records:
        secure_dir(state)
    for h, config, old, new, ins, text, ins_new, entry, block, fragment in records:
        backup = secure_dir(state / h)
        for label, data in (("config", old), ("instructions", text)):
            p = backup / (label + ".bak")
            if not p.exists():
                fd = os.open(str(p), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
                with os.fdopen(fd, "wb") as f:
                    f.write(data)
        receipt = {
            "status": "installed",
            "host": h,
            "entry": entry,
            "config": str(config),
            "instructions": str(ins),
            "config_existed": config.exists(),
            "instructions_existed": ins.exists(),
            "block": block.decode(),
            "fragment": fragment.decode(),
            "config_before_sha256": _sha(old),
            "config_after_sha256": _sha(new),
            "instructions_before_sha256": _sha(text),
            "instructions_after_sha256": _sha(ins_new),
        }
        # Ownership is written first so an interrupted installation is recoverable.
        _atomic(state / (h + ".json"), json.dumps(receipt, indent=2).encode())
        _atomic(config, new)
        _atomic(ins, ins_new)
    return {
        "dry_run": False,
        "changes": changes,
        "status": "installed",
        "restart_required": True,
        "backup_directory": str(state),
        "host_permissions_changed": False,
    }


def uninstall(
    host: Optional[str] = None, dry_run: bool = False, home: Optional[Path] = None
) -> dict:
    home = Path(home or os.environ.get("SWIFTAPI_CONFIG_HOME") or Path.home()).absolute()
    state = home / ".local/state/swiftapi-install"
    result = []
    for h in [host] if host else ["codex", "claude"]:
        if h not in ("codex", "claude"):
            raise InvalidEnvelope("Unknown host")
        rp = state / (h + ".json")
        if not rp.exists():
            result.append({"host": h, "status": "not installed"})
            continue
        r = loads(_read(rp))
        if r["status"] == "uninstalled":
            result.append({"host": h, "status": "not installed"})
            continue
        cfg, ins = Path(r["config"]), Path(r["instructions"])
        old, text = _read(cfg), _read(ins)
        if h == "codex":
            block = r["block"].encode()
            if old.count(block) != 1:
                raise InvalidEnvelope("Managed config changed; preserve it for manual review")
            new = old.replace(block, b"", 1)
        else:
            obj = json.loads(old)
            if obj.get("mcpServers", {}).get(SERVER) != r["entry"]:
                raise InvalidEnvelope("Managed config changed; preserve it for manual review")
            del obj["mcpServers"][SERVER]
            new = (json.dumps(obj, indent=2, ensure_ascii=False) + "\n").encode()
        fragment = r["fragment"].encode()
        if text.count(fragment) != 1:
            raise InvalidEnvelope("Managed instructions changed; preserve them for manual review")
        remaining = text.replace(fragment, b"", 1)
        if not dry_run:
            _atomic(cfg, new)
            _atomic(ins, remaining)
            r["status"] = "uninstalled"
            _atomic(rp, json.dumps(r, indent=2).encode())
        result.append({"host": h, "status": "planned removal" if dry_run else "uninstalled"})
    return {"dry_run": dry_run, "changes": result, "receipts_retained": True}


def doctor(home: Optional[Path] = None) -> dict:
    home = Path(home or os.environ.get("SWIFTAPI_CONFIG_HOME") or Path.home())
    checks = {}
    for h in ("codex", "claude"):
        rp = home / ".local/state/swiftapi-install" / (h + ".json")
        check: dict = {
            "cli_found": bool(shutil.which(h)),
            "installed": False,
            "runtime_qualified": False,
        }
        if rp.exists():
            r = loads(_read(rp))
            try:
                data = _read(Path(r["config"]))
                obj = _toml(data) if h == "codex" else json.loads(data)
                present = obj.get("mcp_servers" if h == "codex" else "mcpServers", {}).get(SERVER)
                check["installed"] = (
                    r["status"] == "installed"
                    and present == r["entry"]
                    and r["fragment"].encode() in _read(Path(r["instructions"]))
                )
                check["interpreter_exists"] = Path(r["entry"]["command"]).is_file()
            except (ValueError, OSError):
                check["error"] = "configuration invalid"
        checks[h] = check
    return {
        "version": "1.3.1",
        "python": sys.version.split()[0],
        "local_brake": "available",
        "hosts": checks,
        "scope": "MCP broker capabilities only; host tools are outside this boundary",
    }
