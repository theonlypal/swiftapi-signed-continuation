"""Inert local qualification. Every case retained; no external consequence."""

from __future__ import annotations
import copy
import time
from pathlib import Path
from .broker import CapabilityBroker
from .core import (
    ActionEnvelope,
    BindingCondition,
    Decision,
    LocalAuthority,
    AuthorizationDenied,
    verify_decision,
    verify_receipt,
    write_exclusive,
)


def qualify(root: Path) -> dict:
    broker = CapabilityBroker(root)
    checks: list[dict] = []
    before = list(broker.sandbox.iterdir())
    broker.status()
    checks.append({"name": "read_only", "passed": list(broker.sandbox.iterdir()) == before})
    request = broker.propose("qualification-marker.txt", "Authorized exactly once.\n")
    rid = request["request_id"]
    denied = broker.execute(rid)
    checks.append(
        {
            "name": "missing_condition",
            "passed": denied["classification"] == "GATE_BLOCK"
            and not list(broker.sandbox.iterdir()),
        }
    )
    broker.authorize(rid)
    granted = broker.execute(rid)
    target = broker.sandbox / "qualification-marker.txt"
    checks.append(
        {
            "name": "authorized_once",
            "passed": granted["classification"] == "AUTHORIZED_EXECUTION"
            and target.read_text() == "Authorized exactly once.\n",
        }
    )
    replay = broker.execute(rid)
    checks.append(
        {
            "name": "replay",
            "passed": replay["classification"] == "GATE_BLOCK"
            and target.read_text() == "Authorized exactly once.\n",
        }
    )
    verify_receipt(granted["receipt"], broker.authority.public_key)
    checks.append({"name": "receipt_independent_verification", "passed": True})
    authority = LocalAuthority()
    action = ActionEnvelope("test-only", {"value": "exact"})
    state = {"approved": True}
    condition = BindingCondition(action.action_hash, state)
    decision = authority.authorize(action=action, condition=condition, state=state)
    cases = []
    cases.append(
        (
            "changed_action",
            decision,
            ActionEnvelope("test-only", {"value": "changed"}),
            condition,
            state,
        )
    )
    cases.append(("changed_state", decision, action, condition, {"approved": False}))
    cases.append(
        (
            "wrong_condition",
            decision,
            action,
            BindingCondition(action.action_hash, state, "another-condition"),
            state,
        )
    )
    cases.append(
        (
            "wrong_capability",
            decision,
            ActionEnvelope("other", {"value": "exact"}),
            condition,
            state,
        )
    )
    forged = decision.to_dict()
    forged["signature"] = "A" * 88
    cases.append(("forged_signature", Decision.from_dict(forged), action, condition, state))
    expired = copy.deepcopy(decision.to_dict()["payload"])
    expired.update(issued_at=int(time.time()) - 10, expires_at=int(time.time()) - 1)
    cases.append(("expired_authorization", authority.sign(expired), action, condition, state))
    for name, d, a, c, s in cases:
        blocked = False
        try:
            verify_decision(d, authority.public_key, a, c, s)
        except AuthorizationDenied:
            blocked = True
        checks.append({"name": name, "passed": blocked})
    result = {
        "schema": "swiftapi.qualification/v1",
        "version": "1.3.1",
        "checks": checks,
        "passed": sum(c["passed"] for c in checks),
        "total": len(checks),
        "status": "PASS" if all(c["passed"] for c in checks) else "FAIL",
        "unauthorized_consequential_escapes": 0 if all(c["passed"] for c in checks) else None,
        "scope": "deterministic local fixtures; no model benchmark was run",
        "receipts": [denied["receipt_path"], granted["receipt_path"], replay["receipt_path"]],
        "public_key": broker.authority.public_key,
    }
    write_exclusive(root / "qualification.json", result)
    return result
