"""Opt-in client for a separately deployed swiftapi.decision/v1 authority.

The legacy swiftapi.ai /verify endpoint is NOT this protocol. No default endpoint
is assumed and no network operation runs on import or local use.
"""

from __future__ import annotations
import asyncio
from urllib.parse import urlparse
from typing import Optional
import requests
from .core import (
    ActionEnvelope,
    BindingCondition,
    Decision,
    InvalidEnvelope,
    canonical,
    loads,
    verify_receipt,
    verify_decision,
)
from ..exceptions import NetworkError, AuthenticationError


class RemoteAuthority:
    def __init__(self, endpoint: str, public_key: str, token: str, timeout: float = 10):
        parsed = urlparse(endpoint)
        if (
            parsed.scheme != "https"
            or not parsed.hostname
            or parsed.username
            or parsed.password
            or parsed.query
            or parsed.fragment
        ):
            raise InvalidEnvelope(
                "Authority endpoint must be an explicit HTTPS URL without credentials/query"
            )
        if not token or not 0 < timeout <= 60:
            raise InvalidEnvelope("Token and bounded timeout required")
        self.endpoint, self.public_key, self._token, self.timeout = (
            endpoint,
            public_key,
            token,
            timeout,
        )

    def authorize(
        self,
        *,
        condition: Optional[BindingCondition],
        action: ActionEnvelope,
        state: dict,
        ttl: int = 300,
    ) -> Decision:
        payload = {
            "schema": "swiftapi.authorization-request/v1",
            "condition": condition.to_dict() if condition else None,
            "action": action.to_dict(),
            "state": state,
            "ttl": ttl,
        }
        try:
            response = requests.post(
                self.endpoint,
                data=canonical(payload),
                headers={
                    "Authorization": "Bearer " + self._token,
                    "Content-Type": "application/json",
                },
                timeout=self.timeout,
                allow_redirects=False,
            )
        except requests.RequestException:
            raise NetworkError("Remote authorization transport failed") from None
        if response.status_code in (401, 403):
            raise AuthenticationError("Remote authority authentication failed")
        if response.status_code != 200:
            raise NetworkError("Remote authority returned non-200 response")
        decision = Decision.from_dict(loads(response.content))
        verify_receipt(decision, self.public_key)
        if decision.allowed:
            if condition is None:
                raise InvalidEnvelope("Remote authority approved an absent condition")
            verify_decision(decision, self.public_key, action, condition, state)
        return decision

    async def authorize_async(self, **kwargs) -> Decision:
        """Cancellation does not cancel the HTTP request; this method never executes an action."""
        return await asyncio.to_thread(self.authorize, **kwargs)
