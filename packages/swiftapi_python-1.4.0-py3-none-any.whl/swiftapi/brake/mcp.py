"""Dependency-light newline-delimited stdio MCP server. No approval tool."""

from __future__ import annotations
import json
import sys
from .broker import CapabilityBroker
from .core import loads, BrakeError


def tools() -> list:
    def tool(name, description, properties, required=(), read_only=False):
        return {
            "name": name,
            "description": description,
            "annotations": {
                "readOnlyHint": read_only,
                "destructiveHint": False,
                "openWorldHint": False,
            },
            "inputSchema": {
                "type": "object",
                "properties": properties,
                "required": list(required),
                "additionalProperties": False,
            },
        }

    string = {"type": "string"}
    return [
        tool(
            "status",
            "Read the broker sandbox, pending requests and public trust key.",
            {},
            read_only=True,
        ),
        tool(
            "propose_marker",
            "Propose an exact new sandbox marker. Does not authorize or execute.",
            {"name": string, "content": string},
            ("name", "content"),
        ),
        tool(
            "execute",
            "Attempt a request. Missing/invalid approval returns GATE_BLOCK; it is not native Void.",
            {"request_id": string},
            ("request_id",),
        ),
        tool(
            "read_marker",
            "Read a small UTF-8 marker inside the configured broker sandbox.",
            {"name": string},
            ("name",),
            read_only=True,
        ),
    ]


def call(broker: CapabilityBroker, name: str, args: dict) -> dict:
    schemas = {t["name"]: t["inputSchema"] for t in tools()}
    if name not in schemas or type(args) is not dict:
        raise BrakeError("Unknown tool or invalid arguments")
    schema = schemas[name]
    if set(args) != set(schema["properties"]) or any(type(v) is not str for v in args.values()):
        raise BrakeError("Invalid arguments")
    if name == "status":
        return broker.status()
    if name == "propose_marker":
        return broker.propose(**args)
    if name == "execute":
        return broker.execute(**args)
    return broker.read_marker(**args)


def serve() -> None:
    broker = CapabilityBroker()
    while True:
        line = sys.stdin.buffer.readline(2 * 1024 * 1024 + 1)
        if not line:
            break
        rid = None
        try:
            if len(line) > 2 * 1024 * 1024:
                raise ValueError("message too large")
            req = loads(line)
            if type(req) is not dict or req.get("jsonrpc") != "2.0":
                raise ValueError("invalid request")
            rid = req.get("id")
            if rid is None:
                continue
            method = req.get("method")
            if method == "initialize":
                requested = req.get("params", {}).get("protocolVersion")
                supported = ["2024-11-05", "2025-03-26", "2025-06-18", "2025-11-25"]
                result = {
                    "protocolVersion": requested if requested in supported else supported[-1],
                    "capabilities": {"tools": {"listChanged": False}},
                    "serverInfo": {"name": "swiftapi_brake", "version": "1.3.1"},
                    "instructions": "Use the broker for its sandbox markers. Approval is operator-only. A denied action is GATE_BLOCK, never native Void.",
                }
            elif method == "ping":
                result = {}
            elif method == "tools/list":
                result = {"tools": tools()}
            elif method == "tools/call":
                try:
                    args = req["params"]
                    value = call(broker, args["name"], args.get("arguments", {}))
                    result = {
                        "content": [
                            {"type": "text", "text": json.dumps(value, ensure_ascii=False)}
                        ],
                        "isError": False,
                    }
                except Exception as exc:
                    result = {
                        "content": [
                            {
                                "type": "text",
                                "text": json.dumps(
                                    {
                                        "classification": "ERROR",
                                        "error": type(exc).__name__,
                                        "executed": False,
                                    }
                                ),
                            }
                        ],
                        "isError": True,
                    }
            else:
                print(
                    json.dumps(
                        {
                            "jsonrpc": "2.0",
                            "id": rid,
                            "error": {"code": -32601, "message": "Method not found"},
                        }
                    ),
                    flush=True,
                )
                continue
            print(
                json.dumps({"jsonrpc": "2.0", "id": rid, "result": result}, ensure_ascii=False),
                flush=True,
            )
        except Exception:
            print(
                json.dumps(
                    {
                        "jsonrpc": "2.0",
                        "id": rid,
                        "error": {"code": -32600, "message": "Invalid request"},
                    }
                ),
                flush=True,
            )


if __name__ == "__main__":
    serve()
