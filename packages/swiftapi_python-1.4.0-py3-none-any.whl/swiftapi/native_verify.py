"""Offline native receipt verification. No torch, weights, signing seed or network.

Signatures authenticate records, not the honesty of an unattested runtime or its
historical online revocation observation. Runtime trust is supplied out of band.
"""
import argparse
import base64
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import re
import struct
from nacl.signing import VerifyKey
from .native_taxonomy import classification_record
from .native_classifier_releases import RELEASED_CLASSIFIER_HASHES
from .verifier import SWIFTAPI_PUBLIC_KEY_B64

EOS, VOCAB = 151645, 151936
MODES = ('RECORDED_LOGITS_REPLAY','FRESH_MODEL_EXECUTION')
UNSIGNED = {'signature','signing_mode','action_data','denial_reason',
            'violated_policies','evaluated_policies','evaluation_context'}

def encoded(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
def digest(raw):
    return hashlib.sha256(raw).hexdigest()
def require(value, message):
    if not value:
        raise ValueError(message)
def read_json(path):
    def unique(pairs):
        d = {}
        for k,v in pairs:
            require(k not in d,'Duplicate JSON member')
            d[k] = v
        return d
    def invalid(_):
        raise ValueError('Nonfinite JSON')
    return json.loads(Path(path).read_bytes(),object_pairs_hook=unique,parse_constant=invalid)
def signature(payload, sig, key):
    VerifyKey(base64.b64decode(key,validate=True)).verify(encoded(payload),base64.b64decode(sig,validate=True))
def instant(value):
    dt = datetime.fromisoformat(value.replace('Z','+00:00'))
    require(dt.tzinfo is not None,'Naive authority timestamp')
    return dt.timestamp()

def verify_revocation_entry(entry, jti, authority_key, *, decision_at=None):
    fields={'cursor','jti','revoked_at','revoked_by','reason'}
    require(isinstance(entry,dict) and set(entry)==fields|{'signature'},'Revocation entry shape')
    require(entry['jti']==jti and type(entry['cursor']) is int and entry['cursor']>0,'Revocation JTI/cursor')
    signature({k:entry[k] for k in fields},entry['signature'],authority_key)
    revoked_at=instant(entry['revoked_at'])
    if decision_at is not None:
        require(revoked_at<=decision_at+5,'Revocation was not established at decision')
    return True
def grant_check(grant, action, when, authority_key):
    """Return the same ordered permission reason, independently of the service."""
    try:
        require(isinstance(grant,dict) and grant.get('signing_mode') == 'ed25519','Authority algorithm')
        signature({k:v for k,v in grant.items() if k not in UNSIGNED},grant['signature'],authority_key)
    except Exception:
        return 'INVALID_AUTHORITY_SIGNATURE'
    if grant.get('action_type') != action['scope'] or grant.get('action_fingerprint') != digest(encoded(action))[:32]:
        return 'GRANT_BINDING_MISMATCH'
    if 'action_data' in grant and grant['action_data'] != action:
        return 'GRANT_ACTION_ECHO_MISMATCH'
    if grant.get('approved') is not True:
        return 'AUTHORITY_DENIED'
    try:
        issued, expires = instant(grant['issued_at']),instant(grant['expires_at'])
    except Exception:
        return 'INVALID_GRANT_TIME'
    if issued > when+5:
        return 'GRANT_FUTURE'
    age_limit = action.get('profile', {}).get('max_grant_age_seconds', 60)
    if type(age_limit) not in (int,float) or not 0 < age_limit <= 3600:
        return 'INVALID_GRANT_AGE_PROFILE'
    if when-issued > age_limit or expires <= when or expires <= issued:
        return 'GRANT_EXPIRED'
    if not isinstance(grant.get('jti'),str) or not re.fullmatch(r'[a-zA-Z0-9_-]{1,128}',grant['jti']):
        return 'INVALID_GRANT_ID'
    return None

def vector(raw):
    require(len(raw) == 2*VOCAB,'Vector byte length')
    vals = [struct.unpack('<f',b'\0\0'+raw[i:i+2])[0] for i in range(0,len(raw),2)]
    require(all(math.isfinite(x) for x in vals),'Nonfinite vector')
    return vals

def verify_receipt(path, trusted_public_key, expected_mode, *, expected_max_grant_age_seconds,
                   authority_key=SWIFTAPI_PUBLIC_KEY_B64,
                   expected_source_sha256=None):
    require(expected_mode in MODES,'Explicit expected mode required')
    require(type(expected_max_grant_age_seconds) in (int,float) and
            0 < expected_max_grant_age_seconds <= 3600,'Expected registered grant age required')
    path = Path(path)
    e = read_json(path)
    require(set(e) == {'payload','signature','signer','algorithm'},'Envelope shape')
    require(e['signer'] == 'LOCAL_RUNTIME' and e['algorithm'] == 'ed25519','Runtime signer')
    r = e['payload']
    signature(r,e['signature'],trusted_public_key)
    require(r['schema'] == 'swiftapi-native-service-receipt/2','Receipt schema')
    require(r['mode'] == expected_mode,'Receipt mode mismatch')
    require(r['runtime_instance'] == digest(base64.b64decode(trusted_public_key)),'Runtime identity')
    require(r['hardware_attested'] is False,'Hardware attestation unsupported')
    require(r['authority_public_key'] == authority_key,'Authority key substituted')
    require(r['source']['sha256'] == digest(encoded(r['source']['files'])),'Service source manifest')
    if expected_source_sha256 is not None:
        require(r['source']['sha256'] == expected_source_sha256,'Unexpected service source')
    require(isinstance(r['sdk']['version'],str) and r['sdk']['version'],'Missing declared SDK version')
    require(r['started_at'] <= r['finished_at'],'Receipt timeline')
    assets = {}
    for name, spec in r['assets'].items():
        require(re.fullmatch(r'[a-zA-Z0-9_.-]+',name) and name not in ('.','..','receipt.json'),'Asset path')
        p = path.parent/name
        require(not p.is_symlink() and p.stat().st_size <= 4000000,'Unsafe asset')
        data = p.read_bytes()
        require(len(data) == spec['bytes'] and digest(data) == spec['sha256'],'Asset hash: '+name)
        assets[name] = data
    require('output.bin' in assets,'Missing output')
    output = assets['output.bin']
    require(r['output'].encode('utf-8') == output,'Raw output binding')
    computed = classification_record(output,r['status'],r.get('result'))
    declared_classifier = r['taxonomy']['classifier_sha256']
    require(isinstance(declared_classifier,str) and declared_classifier in RELEASED_CLASSIFIER_HASHES,
            'Unreleased classifier hash')
    classifier_release = RELEASED_CLASSIFIER_HASHES[declared_classifier]
    require(classifier_release['receipt_schema'] == r['schema'],'Classifier receipt schema')
    require(r['sdk']['classifier_sha256'] == declared_classifier,'Declared SDK classifier binding')
    # Source comments and Unicode database metadata are not classification rules.
    compared = set(computed) - {'unicode_version','classifier_sha256'}
    require(set(r['taxonomy']) == set(computed) and all(
            computed[k] == r['taxonomy'][k] for k in compared),'Taxonomy class/fields mismatch')
    summary = {'status':'PASS','mode':expected_mode,'execution_id':r['execution_id'],
               'class':computed['class'],'response_scope':computed['response_scope'],
               'runtime_signature':'PASS','authority_signature':'NOT_APPLICABLE',
               'asset_hashes':'PASS','physical_execution_attested':False,
               'full_model_forward_pass_reproduced':False,
               'sdk_version_declared':r['sdk']['version'],
               'classifier_sha256_declared':declared_classifier,
               'classifier_first_sdk_version':classifier_release['first_sdk_version'],
               'expected_max_grant_age_seconds':expected_max_grant_age_seconds,
               'authority_public_key':authority_key,
               'authority_evidence_kind':r['authority_evidence_kind'],
               'production_authority':authority_key == SWIFTAPI_PUBLIC_KEY_B64,
               'numerical_boundary_replay':'NOT_PERFORMED_LIGHT_VERIFIER',
               'archived_score_source':'NOT_CHECKED_LIGHT_VERIFIER',
               'revocation_scope':'Historical runtime report, not independently authority-signed'}
    action = r.get('action')
    if action is not None:
        age_limit = action['profile']['max_grant_age_seconds']
        require(type(age_limit) in (int,float) and 0 < age_limit <= 3600,'Signed grant age limit')
        require(age_limit == expected_max_grant_age_seconds,'Registered grant age mismatch')
    if r['authentication'] is not None:
        auth = r['authentication']
        require(grant_check(auth['grant'],auth['action'],auth['observed_at'],authority_key) is None,'Known-key authentication')
        require(auth['action']['scope'] == 'swiftapi.native_service.connection_check','Authentication scope')
        require(auth['action']['instance_id'] == r['runtime_instance'],'Authentication instance')
        require(assets.get('authentication.json') == encoded(auth),'Authentication asset')
        summary['authority_signature'] = 'PASS_CONNECTION_CHECK'
    if r['status'] == 'OPERATIONAL':
        require(computed['class'] == 'operational' and not output and r.get('result') is None,'Operational misrepresented')
        summary['execution_outcome'] = 'OPERATIONAL_NOT_A_VOID'
        return summary
    require(r['status'] == 'COMPLETED' and r['authentication'] is not None,'Completed without known key')
    required = {'request.json','prompt.utf8.bin','input-token-ids.json','grant.json','output.bin','authentication.json'}
    require(required <= set(assets),'Required assets missing')
    action, grant, decision, result = r['action'],r['grant'],r['authority_decision'],r['result']
    require(r['action_sha256'] == digest(encoded(action)),'Action hash')
    require(action['scope'] == 'pccg2.native_decode','Native scope')
    require(action['instance_id'] == r['runtime_instance'],'Action instance')
    require(action['principal_sha256'] == r['authentication']['action']['principal_sha256'],'Principal binding')
    require(action['service_source_sha256'] == r['source']['sha256'],'Action source binding')
    require(action['profile']['mode'] == expected_mode,'Action profile mode')
    req = json.loads(assets['request.json'])
    require({'request_id','question'} <= set(req) <= {'request_id','question','grant'},'Raw request shape')
    require({k:req[k] for k in ('request_id','question')} == action['request'],'Raw request binding')
    require(req.get('grant') == grant and assets['grant.json'] == encoded(grant),'Raw grant binding')
    require(digest(assets['prompt.utf8.bin']) == action['rendered_prompt_sha256'],'Prompt binding')
    require(digest(assets['input-token-ids.json']) == action['input_ids_sha256'],'Input IDs binding')
    require(result['input_ids'] == json.loads(assets['input-token-ids.json']),'Input IDs echo')
    require(result['rendered_prompt_sha256'] == action['rendered_prompt_sha256'] and result['input_ids_sha256'] == action['input_ids_sha256'],'Backend input hashes')
    when = decision['evaluated_at']
    times = r['times']
    require(r['started_at'] == times['request_arrival_at'] <= times['scores_ready_at'] <= when <= r['finished_at'],'Boundary timeline')
    require(times['decision_at'] == when,'Decision timestamp')
    require(times['grant_issued_at'] == (grant.get('issued_at') if isinstance(grant,dict) else None),'Grant timestamp binding')
    current = r['boundary_authentication']
    if current is not None:
        require(grant_check(current['grant'],current['action'],current['observed_at'],authority_key) is None,'Boundary key authentication')
        require(current['action']['scope'] == 'swiftapi.native_service.connection_check' and current['action']['instance_id'] == r['runtime_instance'] and current['action']['principal_sha256'] == action['principal_sha256'],'Boundary authentication binding')
    else:
        require(decision['reason'] == 'KEY_REJECTED_AT_BOUNDARY','Missing boundary authentication')
    check = 'MISSING_PERMISSION' if grant is None else grant_check(grant,action,when,authority_key)
    permission = decision['permission']
    if permission == 'PERMISSION_VERIFIED':
        require(check is None and current is not None and decision['reason'] == 'VERIFIED_EXACT_REQUEST','Unverified permission')
    else:
        require(permission == 'PERMISSION_NOT_VERIFIED','Permission enum')
        reason = decision['reason']
        if reason not in {'REPLAYED_REQUEST','REPLAYED_BOUNDARY_GRANT','AUTHORITY_REVOKED','KEY_REJECTED_AT_BOUNDARY'}:
            require(reason == check or (reason == 'AUTHORITY_DENIED_UNSIGNED' and grant is None),'Denial reason mismatch')
        elif reason == 'AUTHORITY_REVOKED':
            require(check is None,'Revoked grant authenticity/binding')
    signed_denial = check == 'AUTHORITY_DENIED'
    require(decision['denial_authority_signed'] is signed_denial,'Signed denial label')
    if signed_denial:
        require(assets.get('authority-denial.json') == encoded(grant),'Signed denial asset')
    signed_revocation=decision.get('revocation_authority_signed',False)
    require(type(signed_revocation) is bool,'Signed revocation flag')
    if signed_revocation:
        require(decision['reason']=='AUTHORITY_REVOKED' and 'authority-revocation.json' in assets,
                'Signed revocation asset missing or not a revoked decision')
        entry=json.loads(assets['authority-revocation.json'])
        verify_revocation_entry(entry,grant['jti'],authority_key,decision_at=when)
        require(decision['revocation_observation']=='AUTHORITY_SIGNED_ENTRY','Revocation observation label')
        summary['revocation_scope']='AUTHORITY_SIGNED_ENTRY'
    else:
        require('authority-revocation.json' not in assets,'Unlabelled signed revocation evidence')
        require(decision.get('revocation_observation')!='AUTHORITY_SIGNED_ENTRY','Unsigned revocation labelled signed')
    summary['revocation_authority_signed']=signed_revocation
    condition = 'EQ(485487,485487)' if permission == 'PERMISSION_VERIFIED' else 'EQ(485487,485489)'
    require(r['gate_condition'] == result['gate_condition'] == condition,'Derived condition')
    require(result['permission'] == permission and result['gate_condition_truth'] is (permission == 'PERMISSION_VERIFIED'),'Backend permission')
    require(result['schema'] == 'swiftapi-native-backend-result/2' and result['native_eos'] == EOS,'Backend identity')
    require(r['model_executed'] is (expected_mode == MODES[1]),'Content execution mode')
    require(r['execution_facts'] == result['execution_facts'],'Execution facts binding')
    require(r['times']['backend_timing'] == result['timing'],'Backend timing binding')
    require(result['execution_facts']['model_executed'] is r['model_executed'],'Content execution facts')
    tokens = result['generated_token_ids']
    require(tokens and all(type(t) is int and 0 <= t < VOCAB for t in tokens),'Token list')
    cap = 1 if expected_mode == MODES[0] else action['profile']['max_new_tokens']
    require(type(cap) is int and 1 <= cap <= 16,'Configured token budget')
    require(result['max_new_tokens'] == cap and len(tokens) <= cap and EOS not in tokens[:-1],'Token budget/termination')
    complete = tokens[-1] == EOS
    require(result['generation_complete'] is complete,'Completion flag')
    finish = 'NATIVE_EOS' if complete else 'REPLAY_ONE_TOKEN_ONLY' if expected_mode == MODES[0] else 'TOKEN_CAP'
    scope = 'COMPLETE_TO_NATIVE_EOS' if complete else 'FIRST_TOKEN_ONLY_NOT_A_COMPLETE_ANSWER' if expected_mode == MODES[0] else 'TRUNCATED_AT_TOKEN_CAP'
    require(result['finish'] == finish and result['answer_scope'] == scope,'Completion scope')
    require(complete or len(tokens) == cap,'Incomplete trace')
    if permission == 'PERMISSION_NOT_VERIFIED':
        require(tokens == [EOS] and output == b'' and computed['class'] == 'V0','Denied permission did not produce V0')
    require(base64.b64decode(result['output_utf8_base64'],validate=True) == output and result['output_bytes'] == len(output) and result['output_sha256'] == digest(output),'Output evidence')
    require(result['first_token_is_native_eos'] is (tokens[0] == EOS),'First token flag')
    require(len(result['steps']) == len(tokens),'Step count')
    require(result['execution_facts']['forward_passes_completed'] == (len(tokens) if expected_mode == MODES[1] else 0),'Forward-pass count')
    names = {f'{i}-{kind}.bf16.bin' for i in range(len(tokens)) for kind in ('stock','selected')}
    require(set(r['vector_files']) == names,'Vector set')
    for i,step in enumerate(result['steps']):
        raw, vals = [],[]
        for kind in ('stock','selected'):
            name = f'{i}-{kind}.bf16.bin'
            p = path.parent/name
            require(not p.is_symlink() and p.stat().st_size == 2*VOCAB,'Vector path/size')
            data = p.read_bytes()
            require(digest(data) == r['vector_files'][name],'Vector hash')
            raw.append(data); vals.append(vector(data))
        before, after = (data[:2*EOS]+data[2*EOS+2:] for data in raw)
        require(before == after,'Non-EOS bytes changed')
        require(step['index'] == i and step['selected_token'] == tokens[i] == max(range(VOCAB),key=vals[1].__getitem__),'Greedy selection')
        require(step['stock_argmax_token'] == max(range(VOCAB),key=vals[0].__getitem__) and step['selected_logit'] == vals[1][tokens[i]],'Stock argmax/selected score')
        require(step['stock_eos_logit'] == vals[0][EOS] and step['intervened_eos_logit'] == vals[1][EOS],'EOS score binding')
        require(step['stock_vector_sha256'] == digest(raw[0]) and step['selected_vector_sha256'] == digest(raw[1]) and step['non_eos_sha256'] == digest(after),'Score hashes')
        require(step['score_source'] == ('AUTHENTIC_BANK_FIRST_LOGITS' if expected_mode == MODES[0] else 'FRESH_FORWARD_PASS'),'Vector provenance label')
        if i:
            require(raw[0] == raw[1] and step['intervention'] == 'NONE','Later token intervention')
    require(r['stop_cause'] == result['stop_cause'] and r['stop_cause'] in ('NONE','LEARNED_GATE','VETO'),'Stop cause')
    summary.update(tokens=tokens,output_bytes=len(output),non_eos_unchanged=True,
                   authority_signature='CHECKED_PRESENTED_GRANT_AND_CONNECTIONS',
                   permission=permission,reason=decision['reason'])
    return summary

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('receipt',type=Path)
    p.add_argument('--trusted-key',required=True,type=Path)
    p.add_argument('--expected-mode',required=True,choices=MODES)
    p.add_argument('--expected-source-sha256')
    p.add_argument('--expected-max-grant-age-seconds',required=True,type=float,
                   help='Registered value supplied independently, never read from the receipt')
    a=p.parse_args()
    try:
        result=verify_receipt(a.receipt,read_json(a.trusted_key)['public_key'],a.expected_mode,
            expected_max_grant_age_seconds=a.expected_max_grant_age_seconds,
            expected_source_sha256=a.expected_source_sha256)
    except Exception as exc:
        print(json.dumps({'status':'FAIL','reason':str(exc)})); raise SystemExit(2)
    print(json.dumps(result,sort_keys=True))
if __name__ == '__main__':
    main()
