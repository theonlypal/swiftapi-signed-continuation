"""SwiftAPI: verified execution for explicitly mediated capabilities."""
__version__ = "1.4.0"
__author__ = "Rayan Pal"

# Core exports
from .client import SwiftAPI
from .enforcement import Enforcement, enforce
from .verifier import verify_signature, is_valid, get_public_key
from .openai import OpenAI
from .anthropic import Anthropic

# Exceptions
from .exceptions import (
    SwiftAPIError,
    AuthenticationError,
    PolicyViolation,
    SignatureVerificationError,
    AttestationExpiredError,
    AttestationRevokedError,
    RateLimitError,
    NetworkError,
)

# UX utilities
from .utils import (
    Colors,
    Symbols,
    print_approved,
    print_denied,
    print_verified,
    print_error,
    print_info,
)

__all__ = [
    # Version
    "__version__",
    # Core
    "SwiftAPI",
    "Enforcement",
    "enforce",
    # Drop-in replacements
    "OpenAI",
    "Anthropic",
    # Verification
    "verify_signature",
    "is_valid",
    "get_public_key",
    # Exceptions
    "SwiftAPIError",
    "AuthenticationError",
    "PolicyViolation",
    "SignatureVerificationError",
    "AttestationExpiredError",
    "AttestationRevokedError",
    "RateLimitError",
    "NetworkError",
    # UX
    "Colors",
    "Symbols",
    "print_approved",
    "print_denied",
    "print_verified",
    "print_error",
    "print_info",
]

from .brake import (RemoteAuthority, ActionEnvelope, BindingCondition, ContinuationAuthority, Decision,
                    DecisionReceipt, LocalAuthority, LocalGuard, CapabilityBroker,
                    AuthorizationDenied, ReplayError, verify_receipt)
__all__ += ["ActionEnvelope", "BindingCondition", "ContinuationAuthority", "Decision",
            "DecisionReceipt", "LocalAuthority", "LocalGuard", "CapabilityBroker",
            "AuthorizationDenied", "ReplayError", "verify_receipt"]

__all__ += ["RemoteAuthority"]
