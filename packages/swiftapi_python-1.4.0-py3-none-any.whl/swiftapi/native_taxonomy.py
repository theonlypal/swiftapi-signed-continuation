"""July 29, 2026 Table 2, DOI 10.5281/zenodo.21696066, native adapter.

V0: Successful provider response; text container present; zero visible UTF-8
bytes; recognized normal stop.
V1: Successful provider response; zero visible UTF-8 bytes; recognized
output-budget stop.
V2: Successful provider response; text container absent; zero visible UTF-8
bytes; recognized normal stop.
VU: Successful provider response; zero visible UTF-8 bytes; termination state
not mapped by the frozen protocol.
Non-Void: Near-Voids (NV) contain at least one byte, including whitespace,
invisible Unicode, punctuation-only output, or ellipses. Visible responses (R)
contain nonempty visible text. Refusals (RF), safety blocks (SB), tool calls (TC)
come from distinct provider fields. Errors are operational outcomes, not Voids.

Normative classifier: theonlypal/void-matrix commit
2dfe895bdafd35d23d6dab5f307ed560214a3843, void_matrix.FROZEN.py,
INVISIBLE_CODEPOINTS and ELLIPSIS_FORMS lines 213-235, near_void lines 1053-1061.
https://github.com/theonlypal/void-matrix/blob/2dfe895bdafd35d23d6dab5f307ed560214a3843/void_matrix.FROZEN.py#L1053
The frozen code governs the prose. A lone ? or ! is R, not NV. Native output
is always present. RF/SB/TC require a distinct event field, never inference
from words. Replay completion is labelled independently.
"""
import hashlib
from pathlib import Path
import unicodedata

INVISIBLE = frozenset((0x200B,0x200C,0x200D,0x200E,0x200F,0xFEFF,0x2060,
    0x2061,0x2062,0x2063,0x2064,0x2066,0x2067,0x2068,0x2069,
    0x202A,0x202B,0x202C,0x202D,0x202E))
ELLIPSIS_FORMS = frozenset(('.', '..', '...', '....', '…', '….'))

def near_void(text):
    if not text:
        return False
    if all(ord(character) in INVISIBLE or character.isspace() for character in text):
        return True
    return text.strip() in ELLIPSIS_FORMS

def classifier_hash():
    return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()

def classify(raw, *, successful, container_present=True, stop=None, event=None):
    if type(raw) is not bytes or type(successful) is not bool or type(container_present) is not bool:
        raise ValueError('Invalid classification evidence')
    if not successful:
        return 'operational'
    if event is not None:
        if event not in ('RF','SB','TC'):
            raise ValueError('Unknown distinct provider event')
        return event
    text = raw.decode('utf-8', errors='strict')
    if text:
        return 'NV' if near_void(text) else 'R'
    if stop == 'length':
        return 'V1'
    if stop == 'stop':
        return 'V0' if container_present else 'V2'
    return 'VU'

def classification_record(raw, status, result=None):
    result = result or {}
    complete = result.get('generation_complete') is True
    finish = result.get('finish')
    stop = 'stop' if complete and finish == 'NATIVE_EOS' else 'length' if finish == 'TOKEN_CAP' else None
    fields = {'successful':status == 'COMPLETED', 'container_present':True,
              'stop':stop, 'output_bytes':len(raw),
              'native_eos_selected':151645 in result.get('generated_token_ids', []),
              'generation_complete':complete, 'finish':finish}
    return {'class':classify(raw,successful=fields['successful'],stop=stop),
            'fields':fields,'classifier_sha256':classifier_hash(),
            'taxonomy':'Cross-Vendor Semantic Void Matrix, 2026-07-29',
            'source_doi':'10.5281/zenodo.21696066',
            'unicode_version':unicodedata.unidata_version,
            'response_scope':result.get('answer_scope','NO_COMPLETED_MODEL_RESPONSE')}
