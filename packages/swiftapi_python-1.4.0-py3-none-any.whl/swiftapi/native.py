"""Native EOS client. Loopback only; no hosted-model or API-proxy claims."""
from pathlib import Path
import re
from urllib.parse import urlsplit
import uuid
import requests
from .exceptions import SwiftAPIError

class NativeEOSClient:
    def __init__(self, key=None, *, key_file=None, base_url='http://127.0.0.1:8766', timeout=120):
        if (key is None) == (key_file is None):
            raise ValueError('Supply exactly one of key or key_file')
        key = Path(key_file).read_text(encoding='ascii').strip() if key_file is not None else key
        if not isinstance(key,str) or not re.fullmatch(r'swiftapi_live_[0-9a-f]{64}',key):
            raise ValueError('Invalid authority key format')
        u = urlsplit(base_url)
        if (u.scheme != 'http' or u.hostname != '127.0.0.1' or not u.port
                or u.username or u.password or u.path not in ('','/') or u.query or u.fragment):
            raise ValueError('Native service URL must be http://127.0.0.1:PORT')
        self.base_url, self.timeout = base_url.rstrip('/'), timeout
        self.session = requests.Session()
        self.session.trust_env = False
        self.session.headers['X-SwiftAPI-Authority'] = key

    def _post(self, path, body):
        try:
            response = self.session.post(self.base_url+path,json=body,timeout=self.timeout,allow_redirects=False)
        except requests.RequestException:
            raise SwiftAPIError('Native service unavailable') from None
        try:
            data = response.json()
        except ValueError:
            raise SwiftAPIError('Invalid native response',response.status_code) from None
        if response.status_code != 200:
            exc = SwiftAPIError('Native request rejected',response.status_code,data)
            exc.raw_response = response.content
            raise exc
        return data

    def check_authority(self):
        return self._post('/v1/authority/check',{})

    def authorize(self, question, *, request_id):
        return self._post('/v1/native-eos/authorize',{'question':question,'request_id':request_id})

    def generate_with_grant(self, question, grant, *, request_id):
        return self._post('/v1/native-eos/generate',{'question':question,'request_id':request_id,'grant':grant})

    def generate(self, question, *, request_id=None):
        request_id = request_id or str(uuid.uuid4())
        permission = self.authorize(question,request_id=request_id)
        return self.generate_with_grant(question,permission['grant'],request_id=request_id)

    def close(self):
        self.session.close()
    def __enter__(self):
        return self
    def __exit__(self,*_):
        self.close()
